# 🌱 Automated Plant Monitoring & Smart Precision Irrigation System

[![PlatformIO](https://img.shields.io/badge/PlatformIO-Framework-orange?logo=platformio)](https://platformio.org/)
[![Hardware](https://img.shields.io/badge/Hardware-KiCad%20v8.0-blue?logo=kicad)](https://www.kicad.org/)
[![Microcontroller](https://img.shields.io/badge/MCU-ESP32--WROOM--32E-red?logo=espressif)](https://www.espressif.com/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

An enterprise-ready, low-power **IoT Smart Agriculture & Automated Irrigation Controller** designed for automated moisture regulation, environmental monitoring, water conservation, and remote cloud telemetry.

---

## 📌 System Architecture

```text
       +------------------------------------------------------------------+
       |                    POWER SUBSYSTEM                               |
       |  Solar PV Panel (6V) / DC Jack (5V-12V) ---> TP4056 Charger      |
       |                              |                                   |
       |               Li-ion 18650 Battery (3.7V / 2600mAh)              |
       |                              |                                   |
       |                  ME6211C33M5G LDO (3.3V Ultra-Low Iq)            |
       +------------------------------+-----------------------------------+
                                      |
       +------------------------------v-----------------------------------+
       |                 ESP32-WROOM-32E MICROCONTROLLER                  |
       |  - Dual-Core Xtensa LX6 @ 240MHz                                 |
       |  - Deep-Sleep Controller (<15uA)                                 |
       |  - Wi-Fi 802.11 b/g/n & Bluetooth Low Energy                     |
       +-------+--------------------+---------------------+---------------+
               | ADC Inputs         | I2C Bus             | GPIO / PWM
               v                    v                     v
       +---------------+    +-----------------+   +-----------------------+
       | Capacitive    |    | SHT31-D Temp &  |   | MOSFET Relay Driver   |
       | Soil Moisture |    | Humidity Sensor |   | (Controls 5V Submersible|
       | Sensor (v1.2) |    | (I2C 0x44)      |   |  DC Water Pump)       |
       +---------------+    +-----------------+   +-----------------------+
               |                    |                     |
               v                    v                     v
       +---------------+    +-----------------+   +-----------------------+
       | Photodiode    |    | 0.96" OLED      |   | Solenoid Valve /      |
       | Light Sensor  |    | Display (SSD1306|   | Water Level Float     |
       | (Ambient Lux) |    |  Optional)      |   | Switch Sensor         |
       +---------------+    +-----------------+   +-----------------------+
```

---

## 🛠️ Hardware Specifications

| Subsystem | Components & Design Specs |
| :--- | :--- |
| **Main Processing Unit** | ESP32-WROOM-32E (Dual Core 240MHz, 4MB Flash, Wi-Fi & BLE) |
| **Soil Moisture Sensing** | Capacitive Soil Moisture Sensor v1.2 (Corrosion-resistant, Analog Output) |
| **Atmospheric Sensing** | Sensirion SHT31-D / DHT22 (High-accuracy Temperature & Humidity via I2C) |
| **Water Pumping Control** | N-Channel Logic Level MOSFET (IRLZ44N / AO3400A) with Flyback Diode (1N4007) |
| **Water Level Monitoring** | Non-contact / Float Reed Switch for reservoir run-dry safety cutoff |
| **Power Architecture** | TP4056 Solar/USB Li-ion battery charger with ME6211 3.3V low-quiescent LDO |
| **PCB Layer Stack** | 2-Layer FR4 (1.6mm thickness, 1oz Copper, HASL Lead-Free finish) |

---

## 📂 Repository Structure

```plaintext
├── hardware/
│   ├── schematics/
│   │   ├── Plant_Monitor_Schematic.pdf
│   │   └── Schematic_Netlist_Summary.txt
│   ├── pcb_gerber/
│   │   └── README_FABRICATION.txt
│   └── bom/
│       └── Bill_Of_Materials.csv
├── firmware/
│   ├── src/
│   │   ├── main.cpp
│   │   ├── sensor_driver.cpp
│   │   └── pump_controller.cpp
│   ├── include/
│   │   ├── config.h
│   │   └── pump_controller.h
│   └── platformio.ini
├── docs/
│   └── circuit_calculations.md
├── LICENSE
└── README.md
```

---

## ⚡ Power Profile & Sleep Orchestration

- **Moisture & Temp Read Phase:** 35 mA for 120 ms.
- **Wi-Fi Telemetry Upload:** 110 mA for 800 ms.
- **Pumping Cycle:** 450 mA for 3 to 5 seconds (only when soil moisture falls below calibrated threshold).
- **Deep Sleep State:** **14.2 µA** during inactive monitoring intervals (e.g., 30 minutes sleep).
- **Battery Life:** 6 to 9 months continuous operation on a single 18650 cell without solar; indefinite with solar panel.

---

## 🚀 How to Build and Flash

1. Open project in **VS Code** with **PlatformIO Extension**.
2. Configure your Wi-Fi credentials in `firmware/include/config.h`.
3. Connect your ESP32 board via USB.
4. Run:
   ```bash
   pio run --target upload
   pio device monitor
   ```
