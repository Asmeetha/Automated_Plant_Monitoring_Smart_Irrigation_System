========================================================
PCB FABRICATION SPECIFICATIONS (SMART IRRIGATION SYSTEM)
========================================================
Project Name: Automated Plant Monitoring & Smart Irrigation System
Revision: Rev 1.1
Board Layers: 2 Layers
Dimensions: 68.00 mm x 42.00 mm
Thickness: 1.6 mm
Base Material: FR-4 Standard (Tg 130-140C)
Copper Weight: 1 oz (Outer Layers)
Solder Mask Color: Forest Green / Matte Black
Silkscreen: White
Surface Finish: HASL Lead-Free (RoHS Compliant)
Min Trace / Spacing: 0.20mm / 0.20mm (8mil / 8mil)
Power Trace Width (Pump Circuit): 1.5mm (supports up to 1.5A DC surge)
Minimum Hole Size: 0.3mm
