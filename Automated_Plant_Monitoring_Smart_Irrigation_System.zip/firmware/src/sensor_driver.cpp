#include "config.h"
#include <Wire.h>

class SensorDriver {
public:
    static void init() {
        Wire.begin(PIN_I2C_SDA, PIN_I2C_SCL);
        analogReadResolution(12);
    }

    static float readSoilMoisture() {
        uint32_t rawSum = 0;
        for (int i = 0; i < 8; i++) {
            rawSum += analogRead(PIN_SOIL_MOISTURE_ADC);
            delay(10);
        }
        float rawAvg = rawSum / 8.0f;
        
        // Convert to percentage
        float pct = (float)(MOISTURE_DRY_RAW - rawAvg) * 100.0f / (float)(MOISTURE_DRY_RAW - MOISTURE_WET_RAW);
        if (pct < 0.0f) pct = 0.0f;
        if (pct > 100.0f) pct = 100.0f;
        return pct;
    }

    static float readBatteryVoltage() {
        uint32_t raw = analogRead(PIN_BATTERY_ADC);
        // Voltage divider 100k/100k (factor = 2) with 3.3V reference
        return (raw * 3.3f / 4095.0f) * 2.0f;
    }

    static void readAtmospheric(float &temp, float &hum) {
        // Mock SHT31 environmental reading
        temp = 27.8f;
        hum = 64.2f;
    }
};
