#include "pump_controller.h"

void PumpController::init() {
    pinMode(PIN_PUMP_GATE, OUTPUT);
    digitalWrite(PIN_PUMP_GATE, LOW);
    pinMode(PIN_WATER_FLOAT_SWITCH, INPUT_PULLUP);
}

bool PumpController::isWaterReservoirEmpty() {
    // Float switch logic: LOW = water present, HIGH = reservoir empty
    return (digitalRead(PIN_WATER_FLOAT_SWITCH) == HIGH);
}

bool PumpController::dispenseWater(uint32_t durationMs) {
    if (isWaterReservoirEmpty()) {
        Serial.println("[SAFETY] Reservoir is empty! Aborting pump actuation.");
        return false;
    }

    Serial.printf("[ACTUATOR] Activating water pump for %u ms...\n", durationMs);
    digitalWrite(PIN_PUMP_GATE, HIGH);
    delay(durationMs);
    digitalWrite(PIN_PUMP_GATE, LOW);
    Serial.println("[ACTUATOR] Pump closed successfully.");
    return true;
}
