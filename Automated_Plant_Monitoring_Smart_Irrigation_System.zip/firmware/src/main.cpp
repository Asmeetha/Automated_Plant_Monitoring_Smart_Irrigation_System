#include <Arduino.h>
#include "config.h"
#include "pump_controller.h"
#include "sensor_driver.cpp"

void setup() {
    Serial.begin(115200);
    pinMode(PIN_STATUS_LED, OUTPUT);
    digitalWrite(PIN_STATUS_LED, HIGH);

    Serial.println("\n=== [SMART PLANT IRRIGATION SYSTEM BOOT] ===");

    // 1. Initialize Peripheral Drivers
    SensorDriver::init();
    PumpController::init();

    // 2. Acquire Sensor Telemetry
    PlantHealthData data;
    data.soilMoisturePct = SensorDriver::readSoilMoisture();
    data.batteryVoltage = SensorDriver::readBatteryVoltage();
    SensorDriver::readAtmospheric(data.airTempC, data.airHumidityPct);
    data.waterReservoirOk = !PumpController::isWaterReservoirEmpty();
    data.pumpTriggered = false;

    Serial.printf("[TELEMETRY] Soil Moisture: %.1f %%\n", data.soilMoisturePct);
    Serial.printf("[TELEMETRY] Air Temp: %.1f C | Humidity: %.1f %%\n", data.airTempC, data.airHumidityPct);
    Serial.printf("[TELEMETRY] Battery Voltage: %.2f V\n", data.batteryVoltage);
    Serial.printf("[TELEMETRY] Water Reservoir Status: %s\n", data.waterReservoirOk ? "ADEQUATE" : "EMPTY");

    // 3. Automated Closed-Loop Irrigation Logic
    if (data.soilMoisturePct < IRRIGATION_TRIGGER_PCT) {
        Serial.println("[LOGIC] Soil moisture below threshold! Initiating irrigation...");
        data.pumpTriggered = PumpController::dispenseWater(PUMP_MAX_BURST_MS);
    } else {
        Serial.println("[LOGIC] Soil moisture is optimal. No irrigation required.");
    }

    digitalWrite(PIN_STATUS_LED, LOW);

    // 4. Enter Low-Power Deep Sleep
    Serial.printf("[SYSTEM] Entering Deep Sleep for %d seconds...\n", DEEP_SLEEP_SECONDS);
    esp_sleep_enable_timer_wakeup((uint64_t)DEEP_SLEEP_SECONDS * 1000000ULL);
    esp_deep_sleep_start();
}

void loop() {
    // Unused in deep-sleep architecture
}
