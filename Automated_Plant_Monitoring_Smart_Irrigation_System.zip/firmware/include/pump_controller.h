#ifndef PUMP_CONTROLLER_H
#define PUMP_CONTROLLER_H

#include "config.h"

class PumpController {
public:
    static void init();
    static bool dispenseWater(uint32_t durationMs);
    static bool isWaterReservoirEmpty();
};

#endif // PUMP_CONTROLLER_H
