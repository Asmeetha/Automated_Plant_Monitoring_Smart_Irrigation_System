#ifndef CONFIG_H
#define CONFIG_H

#include <Arduino.h>

// Pin Mappings for Smart Irrigation Node
#define PIN_SOIL_MOISTURE_ADC   34
#define PIN_BATTERY_ADC         35
#define PIN_WATER_FLOAT_SWITCH  25
#define PIN_PUMP_GATE           4
#define PIN_STATUS_LED          2

#define PIN_I2C_SDA             21
#define PIN_I2C_SCL             22

// Irrigation Calibration Thresholds
#define MOISTURE_DRY_RAW        3200   // Sensor in dry air
#define MOISTURE_WET_RAW        1450   // Sensor submerged in water
#define IRRIGATION_TRIGGER_PCT  35     // Trigger pump if moisture < 35%
#define PUMP_MAX_BURST_MS       3500   // Max watering burst: 3.5 seconds
#define DEEP_SLEEP_SECONDS      1800   // 30 Minutes telemetry & check cycle

// Telemetry Data Structure
struct PlantHealthData {
    float soilMoisturePct;
    float airTempC;
    float airHumidityPct;
    float batteryVoltage;
    bool  waterReservoirOk;
    bool  pumpTriggered;
};

#endif // CONFIG_H
