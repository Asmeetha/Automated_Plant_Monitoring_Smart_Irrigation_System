# Electrical Design & Calculations: Smart Irrigation System

## 1. Power Consumption & Battery Duration
- **Sensor & MCU Reading Mode ($I_{measure}$):** 35 mA for 0.2 seconds
- **Irrigation Mode ($I_{pump}$):** 450 mA for 3.5 seconds (estimated 2 times per day)
- **Deep-Sleep Mode ($I_{sleep}$):** 14.2 uA (0.0142 mA) for 1799.8 seconds per cycle (30-minute interval)

$$\bar{I}_{idle} \approx \frac{(35 \times 0.2) + (0.0142 \times 1799.8)}{1800} \approx 0.018 \text{ mA}$$

Using an 18650 Li-ion battery (2600 mAh nominal capacity, 2100 mAh usable):
$$\text{Standby Lifespan} = \frac{2100 \text{ mAh}}{0.018 \text{ mA}} \approx 116,000 \text{ Hours} \approx 13 \text{ Years}$$
Factoring in water pump operation twice daily ($450 \text{ mA} \times 3.5 \text{ s} = 0.875 \text{ mAh/day}$), total autonomous life exceeds **8 to 11 months** on battery alone, and runs continuously with a solar panel.

## 2. MOSFET Gate Switching & Flyback Protection
- **MOSFET:** AO3400A (Logic level $V_{GS(th)} = 0.65\text{V} - 1.2\text{V}$, $R_{DS(on)} < 33\text{ m}\Omega$ at $V_{GS}=2.5\text{V}$)
- **Inductive Kickback Voltage Suppression:** Flyback diode 1N4007 across motor terminals limits negative inductive transient $V = -L \frac{di}{dt}$ to safe levels ($<0.7\text{V}$), protecting the MOSFET drain junction.
